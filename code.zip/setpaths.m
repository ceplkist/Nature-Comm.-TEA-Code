% setpaths.m
% for project KINETICS

addpath(genpath('Functions')); % add custom functions to path

clearvars
