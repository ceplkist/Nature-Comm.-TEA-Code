clc
clear all
load ('Sensitivity_result.mat')
counteri
   

for i = (counteri-1)*20000+12000:20000:812000
    counterj=1;
    for j = 4:20:804
        if j == 4
            Visible = 0 ;
    
        fprintf(datestr(now));
        fprintf(' Scenario 1 \n');
        pfad = 'D:\Aspen\Echemical ����\Aspen final\4mw level simulation_v1.bkp';  % name of the aspen model (backup file)
        h = callaspen(pfad,Visible)  ;        % generates handle
        h.SaveAs('test1.bkp') ;                % saves the current file. Thus, the original(base) file remains unchanged even in case of a fatal error during execution.
     
            h.Reinit ;
    
        fprintf(datestr(now));
        fprintf(' Aspen is reinitialized \n');
    
        h.Engine.Run2 ;
        end
    [Objective_function_value,CAPEX,OPEX, profit,cost, el,  CO_targetcost,conv, CO_purify, CO, AOC, AIC] = Objective_function (i, j,h);
    S_cost(counteri,counterj)=CO_targetcost;
    S_conv(counteri,counterj)=conv;
    S_CD(counteri,counterj)=j;
    counterj=counterj+1
    end
    counteri=counteri+1
    save('Sensitivity_result.mat')
end
 
