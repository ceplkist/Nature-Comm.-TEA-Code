function [cost] = pump(p_out,p_in,VFlow,UPF)

if (p_out>p_in) && (VFlow>0)
    % Function which calculates capital pump cost
    % Input in SI
    %
    % INPUT
    %------------------------------------------------
    % Name           | Description                                | Size |
    % p_out          | Pressure of outlet stream                  |[1x1] |
    % p_in           | Pressure of inlet stream                   |[1x1] |
    % VFlow          | Volume flow entering the pump              |[1x1] |
    % UPF            | Upscale factor                             |[1x1] |
    %------------------------------------------------
    %
    % OUTPUT
    %------------------------------------------------
    % Name  | Description                                         | Size |
    % cost  | upscaled capital cost of pump in dollar             |[1x1] |
    %------------------------------------------------
    
    p_out = p_out/10^5; %Pa to bar
    p_in = p_in/10^5; %Pa to bar
    
    VFlow = VFlow *UPF; % upscaled volume flow incl. conversion l/hr in m�/s
    
    %Cost calculation
    C0 = 1500;          % $
    S0 = 20000/60*0.0037854*0.0689;            % [S0]=psig*gal/min -> bar*m�/s
    Smax = 200000/60*0.0037854*0.0689;
    %Smax = 10e99999 ;
    alpha = 0.64;
    FM = 1; %Material type
    F0 = 1.5; %Operation Limit: max Pressure: 500 psig
    
    UF = 576.1/113; %Update factor
    
    %S_raw = (p_out)*VFlow;
    S_raw = (p_out-p_in)*VFlow; %p in bar, VFlow in m^3/s
    
    %Calculating whether Size is within Costing Range, otherwise dividing unit
    %into several units
    if S_raw <= Smax
        Amount = 1;
        S = S_raw;
    else
        Amount = ceil(S_raw/Smax);
        S = S_raw/Amount;
    end
    
    
    BC = C0*(S/S0)^alpha;
    
    %Module factor
    if BC<=2e5
        MF = 3.38;
    elseif 2e5<BC && BC<=4e5
        MF = 3.28;
    elseif 4e5<BC && BC<=6e5
        MF = 3.24;
    elseif 6e5<BC && BC<=8e5
        MF = 3.23;
    elseif 8e5<BC && BC<=10e5
          MF = 3.2;
    else
        MF = 3.2;
        fprintf('BC out of order in pump cost function');
    end
    
    MPF = FM*F0; %Material and pressure factor
    BMC = UF*BC*(MF+MPF-1); %updated bare module cost
    cost = BMC*Amount;
else
    cost = 0.0;
end
end