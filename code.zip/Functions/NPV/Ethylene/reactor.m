function [NR, cost] = reactor(duty, water_an, water_ca)
% Calculate equopment cost for e-chemical co production reactor
% Copywrite reserved Ung Lee 2018.Apr.20

% 1. Parameters
% 1.1 cost

SC    =   96 * 1.2*1070.50/0.429684617; %   KRW  Si PV cell panel (1m x 1.2m)
STS   =    35000 / 0.03 * 1.2; %   TI foil (1m x 1.2m)
IrO   =    37000; %   IrO (KRW/g)
Ag    =    66995; %   Ag foil (1m x 1.2m)
Nf    =  20/0.06*1.2*1070.50; %   nafion (1m x 1.2m)
KHCO3 =   304000; %   KHCO3 (KRW/2.5kg, 99.7%)
KOH   =   198000; %   KOH(KRW/1kg 85%)
Fr    =    13200; %   Frame (1m x 1.2m)
NR  =  round( duty/66.76177934 ); % number of reactor
duty

IrO_cost = IrO *  3.7478952


cost_unit = SC + STS +IrO_cost + Ag + Nf  + Fr 
Nf
KOH_cost = 1 * water_an * 56.1056 * KOH /0.85/ 1000/12 % molar mass KOH (56.1056g/mol) 30 mininutes capa
KHCO3_cost = 0.75 * water_ca * 100.115 * KHCO3 / 0.997 /2.5 /1000/12 % molar mass KHCO3 100.115g/mol 30 mininutes capa
cost = cost_unit * NR + KOH_cost + KHCO3_cost
exchange_rate = 1070.50 %KRW to USD

cost = cost / exchange_rate

 
