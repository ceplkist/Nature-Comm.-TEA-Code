clc
clear all

%% Solver options
% Design variables
% 1 OHC_ON;                   2 LVR_ON;                    3 FEED_STAGE_LVR;             4 FEED_STAGE_PH; 
% 5 COMPR_RATIO_1;            6 COMPR_RATIO_2;             13 OHC_V1_ON
% Operation variables
% 7 HEAT_DUTY_INTERCOOLING_1; 8 HEAT_DUTY_INTERCOOLING_2; 9 HEAT_DUTY_INTERCOOLING_3; 10 HEAT_DUTY_INTERHEATING_1;  11 HEAT_DUTY_INTERHEATING_2; 12 SPLIT_FRAC_CSS; 19 HE 202 OUT TEMP Scenario 1
% 14 HEAT_DUTY_INTERCOOLING_1; 15 HEAT_DUTY_INTERCOOLING_2; 16 HEAT_DUTY_INTERCOOLING_3; 17 HEAT_DUTY_INTERHEATING_1;  18 HEAT_DUTY_INTERHEATING_2; 20 SPLIT_FRAC_CSS; 21 HE 202 OUT TEMP Scenario 2
% 22 HEAT_DUTY_INTERCOOLING_1; 23 HEAT_DUTY_INTERCOOLING_2; 24 HEAT_DUTY_INTERCOOLING_3; 25 HEAT_DUTY_INTERHEATING_1;  26 HEAT_DUTY_INTERHEATING_2; 27 SPLIT_FRAC_CSS; 28 HE 202 OUT TEMP Scenario 3
% 29 HEAT_DUTY_INTERCOOLING_1; 30 HEAT_DUTY_INTERCOOLING_2; 31 HEAT_DUTY_INTERCOOLING_3; 32 HEAT_DUTY_INTERHEATING_1;  33 HEAT_DUTY_INTERHEATING_2; 34 SPLIT_FRAC_CSS; 35 HE 202 OUT TEMP Scenario 4
% 36 fluegas precooling_1; 37 fluegas precooling_2; 38 fluegas precooling_3; 39 fluegas precooling_4;  40 Lean amine precooling_1; 41 Lean amine precooling_2; 42 Lean amine precooling_3 43 Lean amine precooling_4
nvars = 13 ;
lo                  = [0,1,1,2,1.57724888565736,1.56107588397549,-0.020000000000000,-0.020000000000000,-0.020000000000000,0.00000000000000000,0.000000000000000,0.5000000000000,1] ;
up                  = [0,1,1,2,3.77724888565736,4.56107588397549,-0.00000000000000,-0.000000000000000,-0.000000000000000,0.0200000000000000,0.0330000000000000,0.999000000000000,1];
 
IntCon = [1,2,3,4,13] ; % stelle von integer variable
PopulationSize = 30 ; % Size of the population
StallGenLimit = 3 ; 
CrossoverFraction = 0.6 ; % Artur 0.4, Lukas 0.6, Jojo 0.8
maxin = 50 ;
InitialPopulation=[0,1,1,2,1.77724888565736,3.56107588397549,-0.0174018758305254,-0.00440000000000000,-0.0199073155173187,0,0.0137698132797842,0.638485355542187,1]; 
% 'Generations',maxin,
% 'InitialPopulation',initial_population % Positive integer specifying the maximum number of iterations before the algorithm halts 

options= gaoptimset('Display','iter','CrossoverFraction',CrossoverFraction,'EliteCount',1,'InitialPopulation',InitialPopulation,'PopulationSize', PopulationSize, 'StallGenLimit',StallGenLimit,'Generations',maxin)  % options = gaoptimset('param1',value1,'param2',value2,...)

%% Solver which minimizes an objective function

% [x,fval,exitflag,output,population,scores] = ga(fitnessfcn,nvars,A,b,[],[],LB,UB,nonlcon,IntCon, ooptions)
[x,fval,exitflag,output,population,scores] = ga(@(x) Objective_function(x),nvars,[],[],[],[],lo,up,[],[],options) ;

save Matlab_GA_Results.mat
%End