
function [Var_TAC,AOC,AIC,CAPEX,OPEX, profit,cost, el] = TAC(h,k,CD)


    UPF = 1; % scale up factor Aspen -> real process


%% AIC Annual investment cost
base = zeros(6,1);
base_moving = zeros(6,1);

% basecase
base(1) = flash(h.Tree.FindNode('\Data\Streams\CATHIN\Output\STR_MAIN\MASSFLMX\MIXED').value/3600,...
                h.Tree.FindNode('\Data\Streams\CATHIN\Output\STR_MAIN\RHOMX\MIXED').value,...
                h.Tree.FindNode('\Data\Streams\CATHIN\Output\STR_MAIN\PRES\MIXED').value,...
                UPF); %  equipment purchase cost Flash CA-Flash
base_moving(1) = false ;
base(2) = flash(h.Tree.FindNode('\Data\Streams\ANOIN\Output\STR_MAIN\MASSFLMX\MIXED').value/3600,...
                h.Tree.FindNode('\Data\Streams\ANOIN\Output\STR_MAIN\RHOMX\MIXED').value,...
                h.Tree.FindNode('\Data\Streams\ANOIN\Output\STR_MAIN\PRES\MIXED').value,...
                UPF); %  equipment purchase cost Flash An-Flash
base_moving(2) = false ;
base(3) = flash(h.Tree.FindNode('\Data\Streams\S4\Output\STR_MAIN\MASSFLMX\MIXED').value/3600,...
                h.Tree.FindNode('\Data\Streams\S4\Output\STR_MAIN\RHOMX\MIXED').value,...
                h.Tree.FindNode('\Data\Streams\S4\Output\STR_MAIN\PRES\MIXED').value,...
                UPF); %  equipment purchase cost Flash CO-SEP 
base_moving(3) = false ;
base(4) = pump(h.Tree.FindNode('\Data\Streams\S5\Output\STR_MAIN\PRES\MIXED').value,...
               h.Tree.FindNode('\Data\Streams\S8\Output\STR_MAIN\PRES\MIXED').value,...
               h.Tree.FindNode('\Data\Streams\S8\Output\STR_MAIN\VOLFLMX\MIXED').value,...
               UPF); %  equipment purchase cost CA-PUMP
base_moving(4) = true ;
base(5) = pump(h.Tree.FindNode('\Data\Streams\S6\Output\STR_MAIN\PRES\MIXED').value,...
               h.Tree.FindNode('\Data\Streams\S10\Output\STR_MAIN\PRES\MIXED').value,...
               h.Tree.FindNode('\Data\Streams\S10\Output\STR_MAIN\VOLFLMX\MIXED').value,...
               UPF); %  equipment purchase cost AN-PUMP
base_moving(5) = true ;
[cost, el] = reactor_device(h.Tree.FindNode("\Data\Flowsheeting Options\Design-Spec\ENERGYIN\Output\FINAL_VAL\2").value...  
*h.Tree.FindNode("\Data\Flowsheeting Options\Design-Spec\ENERGYIN\Output\FINAL_VAL\3").value,...
               CD);%  equipment purchase cost rxt+PV
base(6) = cost.total;
base_moving(6) = false ;
 % reactor+PV installation cost
water_an = h.Tree.FindNode("\Data\Streams\S5\Output\MASSFLOW\MIXED\WATER").value;
water_ca = h.Tree.FindNode("\Data\Streams\S6\Output\MASSFLOW\MIXED\WATER").value;
KHCO3 =   304000; %   KHCO3 (KRW/2.5kg, 99.7%)
KOH   =   198000; %   KOH(KRW/1kg 85%)
KOH_cost = 1 * water_an * 56.1056 * KOH /0.85/ 1000/12/1070.50 % molar mass KOH (56.1056g/mol) 30 mininutes capa
KHCO3_cost = 0.75 * water_ca * 100.115 * KHCO3 / 0.997 /2.5 /1000/12/1070.50 % molar mass KHCO3 100.115g/mol 30 mininutes capa
PV_install = cost.PV_module * 29/96;
El_install = cost.electrolyzer *19/65;
reactor_PV_install = KOH_cost+KHCO3_cost+PV_install+El_install
% ISBL
CAPEX.Equipment = [base];
CAPEX.ISBL.EPC =  sum(base) % purchased equipment cost
CAPEX.ISBL.EIC =  sum(base(1:5)) ./0.4* 0.12 + base(6)+reactor_PV_install; %Purchased equipment installation 
CAPEX.ISBL.INC =  sum(base) ./0.4* 0.025; % Instrumentation and control 
CAPEX.ISBL.PIP =  sum(base) ./0.4* 0.03; % Piping  
CAPEX.ISBL.Ele =  sum(base) ./0.4* 0.025; % electrical 


% OSBL

CAPEX.OSBL.BS = sum(base) ./0.4* 0.08; %Building and building services 
CAPEX.OSBL.YI = sum(base) ./0.4* 0.02; %Yard improvements 
CAPEX.OSBL.SF = sum(base) ./0.4* 0.08; %Services facilities 
CAPEX.OSBL.LD = sum(base) ./0.4* 0.02; %Land 

% Indirect cost

CAPEX.IND.ENG = sum(base) ./0.4* 0.06; %Engineering
CAPEX.IND.CEX = sum(base) ./0.4* 0.07; %Construction expenses 
CAPEX.IND.COF = sum(base) ./0.4* 0.02; %Contractor��s fee 
CAPEX.IND.COT = sum(base) ./0.4* 0.05; %Contingency 

CAPEX.FCI =  (CAPEX.ISBL.EPC + CAPEX.ISBL.EIC + CAPEX.ISBL.INC + CAPEX.ISBL.PIP + CAPEX.ISBL.Ele...
    + CAPEX.OSBL.BS + CAPEX.OSBL.YI + CAPEX.OSBL.SF + CAPEX.OSBL.LD...
    + CAPEX.IND.ENG + CAPEX.IND.CEX + CAPEX.IND.COF + CAPEX.IND.COF); % Fixed capital investment

CAPEX.WC = CAPEX.FCI*0.1; % working capital
CAPEX.SC = CAPEX.FCI*0.08; % start up cost
CAPEX.Total = CAPEX.FCI*1.18;





i = 0.10 ;
n = 20 ;
CRF = -i/(1-(1+i)^n)  % capital recovery factor (bei Floudas 2012 = 0.154)

AIC = CRF * CAPEX.Total

 %% AOC Annual operating cost
 
laufzeit_h = 3.6*335 ; % operating hours per year
laufzeit_sec = laufzeit_h * 3600;
% cP_water = 4180*1000; % J/(ton*K)
% deltaT = 5;
% 
% 
%%%%%%%%%  water
prize_coolWater = 0.001; % $/ton
water_FR = h.Tree.FindNode("\Data\Streams\COOUT\Output\MASSFLOW\MIXED\WATER").value; %kg/hr
water_cost = water_FR * laufzeit_h*prize_coolWater*UPF;
% 
% 
% 
% % saturated steam Middle pressure at 5 bar and 151.8 C
% cost_middle_pressure_steam=6/1000; %$/kg (cf. Floudas_2012)
% evaporation_energy = 2107 ; % kJ/kg
% 
% 
% heat_inegrated =  h.Tree.FindNode('\Data\Streams\43\Output\QCALC').value /1000 ; % kW
% reboiler_duty = h.Tree.FindNode('\Data\Blocks\SV-201\Output\REB_DUTY').value /1000; % kW 
% 
% inheater_duty = (h.Tree.FindNode('\Data\Blocks\SV-201\Input\HEATER_DUTY\17').value+...
%            h.Tree.FindNode('\Data\Blocks\SV-201\Input\HEATER_DUTY\29').value)*(10^6)/3600; % kW
% 
% heat_required = reboiler_duty - heat_inegrated + inheater_duty ; %kW
% steam_required = heat_required / evaporation_energy ; % in kg/sec
% saturated_steam_cost = steam_required * cost_middle_pressure_steam * laufzeit_sec*UPF; % $/sec * laufzeit_sec
% 
% 
% 
% electricity
% 
price_electricity = 0.00; %$/KWh
electricity_duty = h.Tree.FindNode("\Data\Flowsheeting Options\Design-Spec\ENERGYIN\Output\FINAL_VAL\2").value...
    * h.Tree.FindNode("\Data\Flowsheeting Options\Design-Spec\ENERGYIN\Output\FINAL_VAL\3").value...
    + h.Tree.FindNode("\Data\Flowsheeting Options\Design-Spec\ENERGYIN\Output\FINAL_VAL\4").value...
    * h.Tree.FindNode("\Data\Flowsheeting Options\Design-Spec\ENERGYIN\Output\FINAL_VAL\5").value; % W
 
 electricity_cost = electricity_duty / 1000 * price_electricity*laufzeit_sec*UPF; %$/year
 
 

 
 RM_FR = h.Tree.FindNode("\Data\Streams\COOUT\Output\MOLEFLOW\MIXED\CO").value/28*44; %co2 mass in kg/hr
 OPEX.MC.RM_cost = RM_FR * laufzeit_h / 1000 * 40; %CO2 cost $40/ ton
 OPEX.MC.Uti_cost =  (water_cost  + electricity_cost); %Utility cost
 OPEX.MC.MR_cost = CAPEX.FCI * 0.1; %Maintenace and Repair
 OPEX.MC.OS_cost = CAPEX.FCI * 0.01; %Operating supply
 opexbase =  OPEX.MC.RM_cost + OPEX.MC.Uti_cost + OPEX.MC.MR_cost +OPEX.MC.OS_cost;
 OPEX.MC.OL_cost = opexbase / 0.4  * 0.1; %Operating labor
 OPEX.MC.SC_cost = OPEX.MC.OL_cost  * 0.2; %Direct supervision and clerical labor
 OPEX.MC.LC_cost = OPEX.MC.OL_cost  * 0.2; %Laboratory charge
 OPEX.MC.PR_cost = opexbase / 0.4  * 0.06; %Patent and Royalty
 
 OPEX.FC = opexbase / 0.4  * 0.1; %Fixed charge
 OPEX.PO = opexbase / 0.4  * 0.15; %Plant overhead
 
 OPEX.GE.AD_cost = opexbase / 0.4  * 0.05; %Administrative cost
 OPEX.GE.DS_cost = opexbase / 0.4  * 0.05; %Distribution and selling cost
 OPEX.GE.RD_cost = opexbase / 0.4  * 0.05; %R&D cost
 
 AOC = opexbase / 0.4  * 1;
 
 CO =  h.Tree.FindNode("\Data\Streams\COOUT\Output\MASSFLOW\MIXED\CO").value 
 H2 =  h.Tree.FindNode("\Data\Streams\COOUT\Output\MASSFLOW\MIXED\H2").value
 O2 =  h.Tree.FindNode("\Data\Streams\O2OUT\Output\MASSFLOW\MIXED\O2").value
 CO_cost = CO * laufzeit_h * 0.6
 H2_cost = H2 * laufzeit_h * 0
 O2_cost = O2 * laufzeit_h * 0.33
 profit = CO_cost+H2_cost+O2_cost
 %% TAC Total annuilized cost
 Var_TAC = AIC + AOC ;
end