function [cost] = column(D,L,UPF)
%UNTITLED2 input: D_a=absorber diameter in m; L_a=absorber packing length
%in m;D_s=stripper diameter in m; L_s=stripper packing length
%in m;
%   output: AC=absober equipment cost; SC=stripper equipment cost

% parameter for cost calculation
F_M = 2.1;
rho = 0.284;
t_s = 2;
C_PK = 40;

% upscaling of diameter, length is equal to model
D_max = 25;

C_DR = 3*125*(pi/4)*(3.281*D_max)^2;

V_P=(pi/4)*(3.281 * D_max)^2*(3.281*L);

C_PL = 300.9 *(3.281*D_max)^0.63316*(3.281*L)^0.80161;

W=pi*(39.37*D_max+t_s)*(39.37*(0.8*D_max+L))*t_s*rho;


C_V = exp(7.2756+0.18255*log(W)+0.02297*log(W)^2);


cost_one = F_M*C_V + C_PL + V_P*C_PK + C_DR;

%stream = stream_have * (D_max/D)^2;
%stream_required = stream_have * UPF;


%N = stream_required/stream




cost = cost_one;

end

