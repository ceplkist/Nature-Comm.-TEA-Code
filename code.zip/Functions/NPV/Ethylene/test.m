    Visible = 0 ;
    
        fprintf(datestr(now));
        fprintf(' Scenario 1 \n');
        pfad = 'D:\Aspen\Echemical ����\Aspen final\base case.bkp';  % name of the aspen model (backup file)
        h = callaspen(pfad,Visible)  ;        % generates handle
        h.SaveAs('test1.bkp') ;                % saves the current file. Thus, the original(base) file remains unchanged even in case of a fatal error during execution.
        h.Reinit ;
    
        fprintf(datestr(now));
        fprintf(' Aspen is reinitialized \n');
    
        h.Engine.Run2 ;
    