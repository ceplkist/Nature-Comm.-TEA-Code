function [Objective_function_value,CAPEX,OPEX, profit,cost, el,  CO_targetcost, CO_purify, CO, AOC, AIC] = Objective_function (CD)
%% Solver options
% Design variables
% Design variables
% 1 OHC_ON;                   2 LVR_ON;                    3 FEED_STAGE_LVR;             4 FEED_STAGE_PH; 
% 5 COMPR_RATIO_1;            6 COMPR_RATIO_2;             13 OHC_V1_ON
% Operation variables
% 7 HEAT_DUTY_INTERCOOLING_1; 8 HEAT_DUTY_INTERCOOLING_2; 9 HEAT_DUTY_INTERCOOLING_3; 10 HEAT_DUTY_INTERHEATING_1; 
% 11 HEAT_DUTY_INTERHEATING_2; 12 SPLIT_FRAC_CSS;

OBJ = zeros(1,1);

%% Declare and initialize optimization variables

x
% Continous

k = 1;
    tic; % start calculating cpu time
    %% Initialization of the Aspen Model
%%turn off for sensitivity            
    Visible = 0 ;
    
        fprintf(datestr(now));
        fprintf(' Scenario 1 \n');
        pfad = 'D:\KCRC\Aspen\C2H4\20 tonperyr C2H4 production.bkp';  % name of the aspen model (backup file)
        h = callaspen(pfad,Visible)  ;        % generates handle
        h.SaveAs('test1.bkp') ;                % saves the current file. Thus, the original(base) file remains unchanged even in case of a fatal error during execution.
     
            h.Reinit ;
    
        fprintf(datestr(now));
        fprintf(' Aspen is reinitialized \n');

    
  %%until here  
    
     % run aspen ausf?hren
    
    % If sover converges set CON = 0, if not CON = 1
    s = struct(h.Tree.FindNode("\Data\Results Summary\Run-Status\Output\CVSTAT"));  % bei 1 nicht konvergiert und bei 0 konvergiert
    if isempty(fieldnames(s))|| isnan(h.Tree.FindNode("\Data\Results Summary\Run-Status\Output\CVSTAT").value)
        CON_reinit = 1  % flowsheet did not converge
    else
        CON_reinit = h.Tree.FindNode("\Data\Results Summary\Run-Status\Output\CVSTAT").value;
    end
    
    
    if CON_reinit == 1
        fprintf('\n Warning! The reinitiatialized flowsheet did not converge. \n');
    end
    
    %% Define variable values in Aspen
    
  

    
    % Continous

    
    
    fprintf(datestr(now));
    fprintf(strcat(' Schleife durchlaufen, starte nun Aspen \n'));
    
    %% Run Aspen
    fprintf(datestr(now));
    fprintf(' Variables are changed in Aspen. \n');
    h.Engine.Run2 % run aspen ausf?hren
    %% Check convergence and add penalty
    s = struct(h.Tree.FindNode("\Data\Results Summary\Run-Status\Output\CVSTAT")) ; % bei 1 nicht konvergiert und bei 0 konvergiert
    
    % If sover converges set CON = 0, if not CON = 1
    if isempty(fieldnames(s))|| isnan(h.Tree.FindNode("\Data\Results Summary\Run-Status\Output\CVSTAT").value)
        CON = 1 ; % flowsheet did not converge
    else
        CON = h.Tree.FindNode("\Data\Results Summary\Run-Status\Output\CVSTAT").value;
    end
    
    
    
    if CON == 0
        fprintf(datestr(now));
        fprintf(' Aspen converged. \n ---------------------------------------- \n');
        [Var_TAC,AOC,AIC,CAPEX,OPEX, profit,cost, el,  CO_targetcost, CO_purify, CO] = TAC_Ethylene(h,CD);
        Objective_function_value = round(Var_TAC*1e-3)*1e3 ;
        filename = strcat('Conv_NOIC33', num2str(k),'.bkp') ;
        h.SaveAs(filename) ;
%        conv= h.Tree.FindNode("\Data\Flowsheeting Options\Design-Spec\ENERGYIN\Output\FINAL_VAL\1").value;
    else
        Objective_function_value = 6.6666*1e9 ;
        AOC = 6.6666*1e9;
        AIC = 6.6666*1e9;
        Var_TAC =6.6666*1e9;
        CAPEX=0;
        OPEX=0;
        fprintf(datestr(now));
        fprintf('Warning! Aspen is not converged \n  ---------------------------------------- \n');
        
        % save not converged aspen files in order to check them by hand
        filename = 'Aspen\NotCon_1.bkp' ;
        i = 1 ;
        while ( 2 == exist(filename, 'file')  )
            i = i + 1 ;
            filename = strcat('Aspen\NotCon_', num2str(i),'.bkp') ;
        end
        filename = strcat('NotCon_', num2str(i),'.bkp') ;
        h.SaveAs(filename) ;
        h.Save
    end
    
    OBJ(k) = Objective_function_value ;
    AOC_scenario(k) = AOC ;
    AIC_scenario(k) = AIC ;
   %{ 
    Results = [cr, TTs, BTs, pur71, pur76, HD,heat_integrated, CO2_captured, REN] ;
    Cost = [AOC, AIC, saturated_steam_cost,electricity_cost,cooling_water_cost]
    
    if (k==1)               
        Variables = double([OHC_ON, LVR_ON, FEED_STAGE_LVR, FEED_STAGE_PH, COMPR_RATIO_1, COMPR_RATIO_2, HEAT_DUTY_INTERCOOLING_1,HEAT_DUTY_INTERCOOLING_2, HEAT_DUTY_INTERCOOLING_3, HEAT_DUTY_INTERHEATING_1, HEAT_DUTY_INTERHEATING_2,SPLIT_FRAC_CSS,Split_OHC_Intern]) ;
    else
        Variables = double([OHC_ON, LVR_ON, FEED_STAGE_LVR, FEED_STAGE_PH, COMPR_RATIO_1, COMPR_RATIO_2, HEAT_DUTY_INTERCOOLING_1_Scenario2,HEAT_DUTY_INTERCOOLING_2_Scenario2, HEAT_DUTY_INTERCOOLING_3_Scenario2, HEAT_DUTY_INTERHEATING_1_Scenario2, HEAT_DUTY_INTERHEATING_2_Scenario2,SPLIT_FRAC_CSS,Split_OHC_Intern]) ;
    end
    %}
    cpu_time_min = toc / 60 ; % stop calculating cpu time
    
    %% Saves results in excel
    %{
    G=[k, double(CON),double(CON_reinit),cpu_time_min,Objective_function_value,Variables,Results,Cost] ;
    
    [success,message] = xlsappend('Results_GA.xlsx',G,'GA_Results') ; % [success,message] = xlsappend(file,data,sheet)
    %}
Objective_function_value = max(AIC_scenario) + mean(AOC_scenario) ;
fprintf(datestr(now));
fprintf('Objective value is %d\n ', Objective_function_value );
set(h, 'Visible', 0);
end