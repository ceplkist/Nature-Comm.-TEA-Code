% Sizing and Costing of Expander and Generator
% Parameters are adopted from Turton third addition appendix A1

function [cost] = turbine(W,UPF)

%Radial Gas expander 
FP = W; % Fluid power in kW
NEXP = ceil (FP/1500);
EXP_unit = W/NEXP ;
K1(1) = 2.2476; 
K2(1)= 1.4965;
K3(1) = -0.1618;

C_Gen = 1850000 * ( FP/11800 ) ^ (0.94) ; % Toffolo,A Lazzaretto, A et al Applied energy 2014 A multi criteri approach ---

C_expander = 10^(K1(1)+K2(1)*log10(EXP_unit)+K3(1)*(log10(EXP_unit))^2);
cost=C_expander*NEXP + C_Gen;

    