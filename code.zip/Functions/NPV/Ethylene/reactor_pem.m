function [cost] = reactor_device(duty, water_an, water_ca, CD)
% Calculate equopment cost for e-chemical co production reactor
% Copywrite reserved Ung Lee 2018.Apr.20
% Duty in watt
% 1. Parameters
% 1.1 cost
%CD = current density (mA/cm2)
Elc_Area = duty/(CD * 10 *1.34); % in meter
PV_Area = Elc_Area*13.68/19.27;

SC    =   (0.37*duty)/0.429684617*1070.50; %   KRW  Si single crystal PV cell panel 
STS   =    35000 / 0.03 * Elc_Area; %   TI foil (support)
IrO   =    37000 / 0.001927 * Elc_Area; %   IrO (KRW/g)
Ag    =    581 *6.285 / 2 / 0.001927 * Elc_Area; %   Ag foil 
mem    =   190/0.06*1.2*1070.50; %   nafion 
KHCO3 =   304000; %   KHCO3 (KRW/2.5kg, 99.7%)
KOH   =   198000; %   KOH(KRW/1kg 85%)
Fr    =    13200 / 1.2 * area; %   Frame


IrO_cost = IrO *  3.7478952;



%KOH_cost = 1 * water_an * 56.1056 * KOH /0.85/ 1000/12 % molar mass KOH (56.1056g/mol) 30 mininutes capa
%KHCO3_cost = 0.75 * water_ca * 100.115 * KHCO3 / 0.997 /2.5 /1000/12 % molar mass KHCO3 100.115g/mol 30 mininutes capa

cost.PV_module = SC
cost.PV_mount = SC * 29 / 96
cost.PV_BOS = SC * 56 / 96

cost.electrolyzer = (STS +IrO_cost + Ag + mem  + Fr)%+ KOH_cost + KHCO3_cost
cost.wiring = SC/ 96 *16
%% 

%for 40MW only
%cost.electrolyzer.BOS = cost.electrolyzer/ 65 *61
%
%% 
z = struct2cell(cost(:));
out = sum(reshape([z{:}],size(z)),2);

exchange_rate = 1070.50 %KRW to USD

cost.total = sum(out) / exchange_rate

 
